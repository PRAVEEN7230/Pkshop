const nodemailer = require("nodemailer")

const transporter = nodemailer.createTransport({
  service: "gmail",
  auth: {
    user: process.env.EMAIL,
    pass: process.env.EMAIL_PASS,
  },
});


const sendMail = (lessStockProducts)=>{

  const html = `<html>
  <table width="90%" style="border:1px solid #333">
    <tr>
      <td align="center">STOCK INFORMATION</td>
    </tr>
    <tr>
      <td align="center">
        Product Details
        <table align="center" width="80%" border="1" cellspacing="3%" cellpadding="5%" style="border:1px solid #ccc;">
          <tr>
            <th colspan="3"> Name </td>
            <th> Stock </td>
          </tr>`
  lessStockProducts.forEach(product => {
    html += `<tr>
              <td colspan="3">${product[0]}</td>
              <td>${product[1]}</td>
            </tr>`
  })
  html += `</table>
          </td>
        </tr>
        </table>
        </html>`
                      
  
  
  transporter.sendMail({
    from: process.env.EMAIL,
    to: "praveensuthar7230@gmail.com",//, harshchoudhary437@gmail.com, navedshamsi.calories@gmail.com, chandrakiranb27@gmail.com, om29287@gmail.com",
    subject: "Stock Alert",
    html: html,
  }, function (error, info) {
    if (error) {
      console.log(error);
    } else {
      console.log("Email sent: " + info.response);
    }
  });
    
}
module.exports=sendMail