const mongoose = require("mongoose");

const DiscountCouponSchema = new mongoose.Schema(
  { users: [
    {
      userId: {type: mongoose.SchemaTypes.ObjectId, ref: "User"}
    }
  ],
    discountCoupon:{
        couponCode: { type: String, required: true },
        discount: { type: Number, default: 10, },
        minimumOrderValue: { type: Number, default: 500, },
        flatDiscount: {type: Boolean, default: false},
        upto: { type: Number},
        category: { type: String},
      },
  },
  { timestamps: true }
);

module.exports = mongoose.model("DiscountCoupon", DiscountCouponSchema);
